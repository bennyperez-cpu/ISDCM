/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isdcm.tools;
import isdcm.model.usuario;

/**
 *
 * @author Benny Hammer Pérez Vasquez
 */
public interface Validar {
    public int validar(usuario usu);
    
}
