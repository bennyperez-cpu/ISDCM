/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signature;

import com.sun.xacml.ParsingException;
import com.sun.xacml.UnknownIdentifierException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author fiblabs
 */
public class GenEnveloped {
    public static void main(String[] args) throws ParsingException, IOException, UnknownIdentifierException, SAXException, ParserConfigurationException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, KeyException, MarshalException, TransformerException, XMLSignatureException {
        // Instantiating the Document to be Signed
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        
        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document doc = builder.parse(new FileInputStream(args[0]));
        
        // Creating a Public Key Pair
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("DSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();
        
        // Creating a Signing Context
        DOMSignContext dsc = new DOMSignContext (kp.getPrivate(), doc.getDocumentElement());
        
        // Assembling the XML Signature
        XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
        
        // Creates the reference object
        Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA256, null), 
                Collections.singletonList(fac.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null)), null, null);
        
        // Creates the SignedInfo object,
        SignedInfo si = fac.newSignedInfo(fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS,
                (C14NMethodParameterSpec) null),fac.newSignatureMethod("http://www.w3.org/2009/xmldsig11#dsa-sha256", null), 
                Collections.singletonList(ref)); 
        
        // Creates the optional KeyInfo object, which contains information that enables the recipient to find the key needed to validate the signature
        KeyInfoFactory kif = fac.getKeyInfoFactory(); 
        
        // Creates the KeyValue object and add it to a KeyInfo object
        KeyValue kv = kif.newKeyValue(kp.getPublic());
        KeyInfo ki = kif.newKeyInfo(Collections.singletonList(kv)); 
        
        // Create the XMLSignature object, passing as parameters the SignedInfo and KeyInf
        XMLSignature signature = fac.newXMLSignature(si, ki); 
        
        // Generating the XML Signature
        signature.sign(dsc);
        
        // Printing the Resulting Document
        OutputStream os;
        if (args.length > 1) {
          os = new FileOutputStream(args[1]); //if we have specified a filePath as argument
        } else {
          os = System.out;
        } 
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer trans = tf.newTransformer();
        trans.transform(new DOMSource(doc), new StreamResult(os));
    }
    
}
